#define TITLE "iHDR"
#define VERSION "2.0"

#feature-id iHDR : Sketchpad > iHDR

#feature-info This utility allows for the easy application of iteration-based HDR.< br />\
    <br />\
    This script is used for HDR-based image stretching.\
    <br />\
	Made by Mr. Sketchpad

#include <pjsr/ColorSpace.jsh>
#include <pjsr/DataType.jsh>
#include <pjsr/FrameStyle.jsh>
#include <pjsr/NumericControl.jsh>
#include <pjsr/SampleType.jsh>
#include <pjsr/Sizer.jsh>
#include <pjsr/UndoFlag.jsh>

// The script's parameters prototype.
function parametersPrototype()
{
   this.setDefaults = function()
   {
	  this.oldCheck = true;
	  this.presets = 0;
      this.iterations = 3;
	  this.intensity = 0.30;
	  this.maskStrength = 3;
	  this.preservation = 6;
	  this.layersPer = 1;
	  this.repetitions = 1;
	  this.showTemp = false;
	  this.layerNames = [];
   };

   this.setParameters = function()
   {
      Parameters.clear();
      Parameters.set( "iterations", this.iterations );
      Parameters.set( "intensity", this.intensity );
      Parameters.set( "maskStrength", this.maskStrength );
      Parameters.set( "preservation", this.preservation );
      Parameters.set( "layersPer", this.layersPer );
   };

   this.getParameters = function()
   {
      if ( Parameters.has( "iterations" ) )
         this.iterations = Parameters.getReal( "iterations" );
	  if ( Parameters.has( "intensity" ) )
         this.intensity = Parameters.getReal( "intensity" );
	  if ( Parameters.has( "maskStrength" ) )
         this.maskStrength = Parameters.getReal( "maskStrength" );
	  if ( Parameters.has( "preservation" ) )
         this.preservation = Parameters.getReal( "preservation" );
	  if ( Parameters.has( "layersPer" ) )
         this.layersPer = Parameters.getReal( "layersPer" );

   };
}

function Preset()
{
}
Preset.prototype.Galaxy= 0;
Preset.prototype.GalaxyDust = 1;
Preset.prototype.Nebula = 2;
Preset.prototype.Cluster = 3;


var parameters = new parametersPrototype();
parameters.setDefaults();
parameters.getParameters();

// Returns a push button with given text and onClick function.
function pushButtonWithTextOnClick( parent, text_, onClick_ )
{
   let button = new PushButton( parent );
   button.text = text_;
   button.onClick = onClick_;
   return button;
}

function fieldLabel( parent, text, width )
{
   this.label = new Label( parent );
   this.label.text = text;
   this.label.textAlignment = TextAlign_Right | TextAlign_VertCenter;
   if ( width != undefined && width != null )
      this.label.setFixedWidth( width );
   return this.label;
}

function createSpinBox(parent, min, max, val, onUpdate, toolTip="") {
   this.spinBox = new SpinBox( parent );
   this.spinBox.minValue = min;
   this.spinBox.maxValue = max;
   this.spinBox.precision = 2;
   this.spinBox.toolTip = toolTip;
   this.spinBox.setFixedWidth( 65 );
   this.spinBox.value = val
   this.spinBox.onValueUpdated = onUpdate;
   return spinBox;
}

// The script's parameters dialog prototype.
function parametersDialogPrototype()
{
   this.__base__ = Dialog;
   this.__base__();
   
   //this.minWidth = 600;

   let labelMinWidth = Math.round( this.font.width( "Iterations:" ) + 2*this.font.width( 'M' ) );

   this.windowTitle = TITLE;

   this.titlePane = new Label( this );

   this.titlePane.frameStyle = FrameStyle_Box;
   this.titlePane.margin = 4;
   this.titlePane.wordWrapping = true;
   this.titlePane.useRichText = true;
   this.titlePane.text =
      "<p><b>" + TITLE + " Version " + VERSION + "</b> &mdash; " +
      "Multiscale iterative HDR. Use this script to preserve bright areas while bringing out fainter components of the image."
	  +"<p>Instructions:"
	  +"<br>1. Stretch the image such that its brightest components are at the final desired brightness."
	  +"<br>2. Create a preview on the darkest part if your image to be used in the 'BG View' parameter."
	  +"<br>3. Select the appropriate preset and apply the script.</p>"
	  +"You may find that you need to run the script multiple times.</p>"
	  +"<p>Made by Uri Darom</p>";
    
   // Target View
   this.targetView = new VerticalSizer;
   this.targetView.margin = 6;
   this.targetView.spacing = 4;

   this.viewList = new ViewList( this );
   this.viewList.getMainViews();
   if ( parameters.targetView && parameters.targetView.isView )
   {
      this.viewList.currentView = parameters.targetView;
   }
   else
      parameters.targetView = this.viewList.currentView;

   this.viewList.onViewSelected = ( view ) =>
   {
      parameters.targetView = view;
   };

   this.targetView.add( this.viewList );
   this.TargetGroup = new GroupBox( this );
   this.TargetGroup.title = "Target View";
   this.TargetGroup.sizer = this.targetView;
   
   // BG Preview
   this.bgList = new VerticalSizer;
   this.bgList.margin = 6;
   this.bgList.spacing = 4;

   this.viewList = new ViewList(this);
   this.viewList.getAll();
   this.viewList.onViewSelected = ( view ) =>
   {
      parameters.bgView = view;
   };

   this.bgList.add( this.viewList );
   this.BGGRoup = new GroupBox( this );
   this.BGGRoup.title = "BG View";
   this.BGGRoup.sizer = this.bgList;

   // Parameter control
   this.parameterPane = new VerticalSizer;
   this.parameterPane.scaledMargin = 6;
   this.parameterPane.scaledSpacing = 10;
   this.parameterPane.margin = 5;

   this.iterationsControl = new NumericControl( this );
   this.iterationsControl.label.text = "Stretch Iterations:";
   this.iterationsControl.label.minWidth = labelMinWidth;
   this.iterationsControl.slider.setRange( 1, 14 );
   this.iterationsControl.slider.setScaledMinWidth( 300 );
   this.iterationsControl.setRange( 1, 14 );
   this.iterationsControl.setPrecision( 0 );
   this.iterationsControl.setValue( parameters.iterations );
   this.iterationsControl.toolTip =
      "<p>The number of HDR iterations.</p>";
   this.iterationsControl.onValueUpdated = function( value )
   {
      parameters.iterations = value;
   };
   
   /*
   this.layerControl = new NumericControl( this );
   this.layerControl.label.text = "Layers Per Iteration:";
   this.layerControl.label.minWidth = labelMinWidth;
   this.layerControl.slider.setRange( 1, 14 );
   this.layerControl.slider.setScaledMinWidth( 300 );
   this.layerControl.setRange( 1, 14 );
   this.layerControl.setPrecision( 0 );
   this.layerControl.setValue( parameters.layersPer );
   this.layerControl.toolTip =
      "<p>The number of layers masked per iteration.</p>";
   this.layerControl.onValueUpdated = function( value )
   {
      parameters.layersPer = value;
   };
   */
   
   this.intensityControl = new NumericControl( this );
   this.intensityControl.label.text = "Stretch Intensity:";
   this.intensityControl.label.minWidth = labelMinWidth;
   this.intensityControl.slider.setRange( 0, 100 );
   this.intensityControl.slider.setScaledMinWidth( 300 );
   this.intensityControl.setRange( 0.0, 1.0 );
   this.intensityControl.setPrecision( 2 );
   this.intensityControl.setValue( parameters.intensity );
   this.intensityControl.toolTip =
      "<p>The intensity of the stretch. A greater number results in a brighter stretch per iteration.</p>";
   this.intensityControl.onValueUpdated = function( value )
   {
      parameters.intensity = value;
   };
   
   this.maskStrengthControl = new NumericControl( this );
   this.maskStrengthControl.label.text = "Mask Strength:";
   this.maskStrengthControl.label.minWidth = labelMinWidth;
   this.maskStrengthControl.slider.setRange( 0, 10 );
   this.maskStrengthControl.slider.setScaledMinWidth( 300 );
   this.maskStrengthControl.setRange( 0.0, 10.0 );
   this.maskStrengthControl.setPrecision( 2 );
   this.maskStrengthControl.setValue( parameters.maskStrength );
   this.maskStrengthControl.toolTip =
      "<p>The strength of the masks. A greater value will protect the brighter areas of the image more.</p>";
   this.maskStrengthControl.onValueUpdated = function( value )
   {
      parameters.maskStrength = value;
   };
   
   this.preservationControl = new NumericControl( this );
   this.preservationControl.label.text = "Layer Preservation:";
   this.preservationControl.label.minWidth = labelMinWidth;
   this.preservationControl.slider.setRange( 0, 13 );
   this.preservationControl.slider.setScaledMinWidth( 300 );
   this.preservationControl.setRange( 0.0, 13.0 );
   this.preservationControl.setPrecision( 0 );
   this.preservationControl.setValue( parameters.preservation );
   this.preservationControl.toolTip =
      "<p>Which layers are preserved in the stretch. Use greater values when targeting smaller objects.</p>";
   this.preservationControl.onValueUpdated = function( value )
   {
      parameters.preservation = value;
   };
   
   var self = this;
   
   this.oldCheck = new CheckBox(this);
   this.oldCheck.text = "Use old behavior";
   this.oldCheck.toolTip = "<p>Not recommended. Reverts script behavior to that of the 1.0 version. "
                          +"This setting effectively reduces the effect of HDR on small objects. "
						  +"Checking this option may slightly reduce run time.</p>"
   this.oldCheck.checked = !parameters.oldCheck;
   this.oldCheck.onCheck = function (checked)
   {
      parameters.oldCheck = !checked;
   };
   
   this.repeatLabel = fieldLabel( this, "Repetitions: ", 85);
   this.repeatSpinbox = createSpinBox(this, 1, 100000, parameters.repetitions, function (value) {parameters.repetitions = parseFloat(value);}, "The number of times the script will be repeated on the target image.");
   
   this.presetLabel = new Label(this);
   this.presetLabel.text = "Preset:";
   this.presetLabel.textAlignment = TextAlign_Left | TextAlign_VertCenter;
   this.presetCombo = new ComboBox(this);
   this.presetCombo.editEnabled = false;
   this.presetCombo.toolTip = "<p>Select the option closest to your target, and the settings will be changed appropriately.</p>";
   this.presetCombo.addItem("Galaxy");
   this.presetCombo.addItem("Galaxy + Dust");
   this.presetCombo.addItem("Nebula");
   this.presetCombo.addItem("Star Cluster");
   this.presetCombo.currentItem = parameters.presets ? parameters.presets : 0;
   this.presetCombo.onItemSelected = function ()
   {
      parameters.presets = this.currentItem;
	  if (this.currentItem == 0) {
		parameters.repetitions = 1;
		parameters.iterations = 3;
		parameters.layersPer = 1;
		parameters.intensity = 0.30;
		parameters.maskStrength = 3;
		parameters.preservation = 6;
	  }
	  else if (this.currentItem == 1) {
		parameters.repetitions = 1;
		parameters.iterations = 5;
		parameters.layersPer = 1;
		parameters.intensity = 0.22;
		parameters.maskStrength = 4;
		parameters.preservation = 7;
	  }
	  else if (this.currentItem == 2) {
		parameters.repetitions = 1;
		parameters.iterations = 5;
		parameters.layersPer = 1;
		parameters.intensity = 0.24;
		parameters.maskStrength = 2;
		parameters.preservation = 3;
	  }
	  else if (this.currentItem == 3) {
		parameters.repetitions = 1;
		parameters.iterations = 5;
		parameters.layersPer = 1;
		parameters.intensity = 0.30;
		parameters.maskStrength = 1;
		parameters.preservation = 0;
	  }
	  self.repeatSpinbox.value = parameters.repetitions;
	  self.iterationsControl.setValue(parameters.iterations);
	  //self.layerControl.setValue(parameters.layersPer);
	  self.intensityControl.setValue(parameters.intensity);
	  self.maskStrengthControl.setValue(parameters.maskStrength);
	  self.preservationControl.setValue(parameters.preservation);
   };
   
   this.presetSizer = new HorizontalSizer();
   this.presetSizer.scaledSpacing = 4;
   this.presetSizer.add(this.presetLabel);
   this.presetSizer.add(this.presetCombo);
   this.presetSizer.add(this.repeatLabel);
   this.presetSizer.add(this.repeatSpinbox);
   this.presetSizer.addSpacing(20);
   this.presetSizer.add(this.oldCheck);
   this.presetSizer.margin = 10;
   this.presetSizer.addStretch();
   
   this.optionGroup = new GroupBox( this );
   this.optionGroup.title = "Options";
   this.optionGroup.sizer = this.presetSizer;
  
   this.PrLiPane = new HorizontalSizer;
   this.PrLiPane.addUnscaledSpacing( labelMinWidth + this.logicalPixelsToPhysical( 4 ) );
   this.PrLiPane.addStretch();
   
   this.sliderSizer = new VerticalSizer();
   this.sliderSizer.scaledSpacing = 10;
   this.sliderSizer.margin = 15;
   this.sliderSizer.add( this.iterationsControl );
   //this.sliderSizer.add( this.layerControl );
   this.sliderSizer.add( this.intensityControl );
   this.sliderSizer.add( this.maskStrengthControl );
   this.sliderSizer.add( this.preservationControl );

   this.parameterPane.add( this.optionGroup );
   this.parameterPane.add( this.sliderSizer );
   this.parameterPane.add( this.PrLiPane );

   this.buttonPane = new HorizontalSizer;
   this.buttonPane.spacing = 6;
   this.buttonPane.addStretch();
   this.ok_Button = new PushButton(this);
   this.ok_Button.text = "Execute";
   this.ok_Button.icon = this.scaledResource( ":/icons/ok.png" );
   this.ok_Button.onClick = function ()
   {
      this.dialog.ok();
   };
   this.buttonPane.add(this.ok_Button);
   
   this.cancel_Button = new PushButton(this);
   this.cancel_Button.text = "Close";
   this.cancel_Button.icon = this.scaledResource( ":/icons/cancel.png" );
   this.cancel_Button.onClick = function ()
   {
      this.dialog.cancel();
   };
   this.buttonPane.add(this.cancel_Button);
   

   this.bottomBarPane = new HorizontalSizer;

   this.newInstanceButton = new ToolButton( this );
   this.newInstanceButton.icon = this.scaledResource( ":/process-interface/new-instance.png" );
   this.newInstanceButton.setScaledFixedSize( 24, 24 );
   this.newInstanceButton.toolTip = "New Instance";
   this.newInstanceButton.onMousePress = function()
   {
      this.hasFocus = true;
      this.pushed = false;
      parameters.setParameters();
      this.dialog.newInstance();
   };

   this.bottomBarPane.add( this.newInstanceButton );
   this.bottomBarPane.add( this.buttonPane );


   this.sizer = new VerticalSizer;
   this.sizer.margin = 6;
   this.sizer.spacing = 6;
   this.sizer.add( this.titlePane );
   this.sizer.add( this.TargetGroup );
   this.sizer.add( this.BGGRoup );
   this.sizer.add( this.parameterPane );
   this.sizer.add( this.bottomBarPane );

   this.adjustToContents();
   this.setFixedSize();
}

parametersDialogPrototype.prototype = new Dialog;

function mmt(layersDisabled, targetView, disable=true) {
	var P = new MultiscaleMedianTransform;
	var layers = [
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 1
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 2
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 4
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 8
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 16
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 32
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 64
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 128
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 256
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 512
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000]
	];
	for (let i = 0; i < 16; i++) {
	  if (i<layersDisabled) layers[i][0] = !disable;
	  else layers[i][0] = disable;
	}
	P.layers = layers;
    P.transform = MultiscaleMedianTransform.prototype.MultiscaleMedianTransform;
    P.executeOn(targetView, true );
}

function singleLayerMMT(targetView, layer, enabled = true) {
	var P = new MultiscaleMedianTransform;
	var layers = [
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 1
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 2
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 4
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 8
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 16
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 32
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 64
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 128
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 256
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],  // 512
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000],
		 [true, true, 0.000, false, 1.0000, 1.00, 0.0000]
	];
	if (enabled) {
		for (let i = 0; i<16; i++) {
			if (i!=layer-1) layers[i][0] = false;
		}
	}
	else layers[layer-1][0] = false;
	P.layers = layers;
    P.transform = MultiscaleMedianTransform.prototype.MultiscaleMedianTransform;
    P.executeOn(targetView, true );
}

function pixelMath(targetView, expression, createImage = false, imageId = "", grayscale = false) {
	var P = new PixelMath;
	P.expression = expression
	P.useSingleExpression = true;
	P.symbols = "M, S="+(1-((parameters.intensity/2)+0.5));
	P.singleThreaded = false;
	P.optimization = true;
	P.createNewImage = createImage;
	P.showNewImage = parameters.showTemp;
	P.newImageId = imageId;
	if (grayscale) P.newImageColorSpace = 2;
	else P.newImageColorSpace = PixelMath.prototype.SameAsTarget;
	P.newImageSampleFormat = PixelMath.prototype.SameAsTarget;
	P.executeOn(targetView, true );
}

function splitLayers(targetView, num, min = 0) {
	for (let i = 0; i<num; i++) {
		var name = getNewName(targetView.id+"_Layer"+i);
		pixelMath(targetView, "$T", true, name);
        var layer = View.viewById(name);
        singleLayerMMT(layer, i+min);
        parameters.layerNames[i] = name;		
	}
}

function getNewName(name)
{
   var newName = name;
   let n = 1;
   while (!ImageWindow.windowById(newName).isNull)
   {
      ++n;
      newName = name + n;
   }
   return newName;
}

// The script's process prototype.
function processPrototype()
{
   var reps = 1;
   var self = this;
   this.execute = function()
   {
	  var oldMed = parameters.bgView.image.median();
	  var targetName = getNewName("target");
	  pixelMath(parameters.targetView, "$T", true, targetName, false);
	  var target = View.viewById(targetName);
	  
	  let HT = new HistogramTransformation;
	    HT.H = [
				[0, 0.5, 1.0, 0.0, 1.0],
				[0, 0.5, 1.0, 0.0, 1.0],
				[0, 0.5, 1.0, 0.0, 1.0],
				[parameters.bgView.image.median()/2, 0.5, 1.0, 0.0, 1.0],
			 ]
	   HT.executeOn(target, true);
	  
	  //pixelMath(target, "$T-"+parameters.bgView.image.median()+"+0.03", false, "", false);
	  var runs = 0;
	  for (let i = 0; i < parameters.iterations*parameters.layersPer; i += parameters.layersPer) {
		console.noteln("Iteration ", (i/parameters.layersPer)+1+"/"+parameters.iterations);
		var tempName = getNewName("temp");
	    var maskName = getNewName("Mask");
		pixelMath(target, "$T", true, tempName, false);
		pixelMath(target, "iif(isColor(), Avg($T[0], $T[1], $T[2]), $T)", true, maskName, true);
		var mask = View.viewById(maskName);

		var layersToDisable = i+parameters.preservation;
		
		if (parameters.oldCheck) {
			
			 var grayTargetName = getNewName("grayTarget");
			 pixelMath(target, "iif(isColor(), Avg($T[0], $T[1], $T[2]), $T)", true, grayTargetName, true);
			 var grayTarget = View.viewById(grayTargetName);
			  
			 grayTarget.window.createPreview(0, parameters.targetView.window.width, 0, parameters.targetView.window.height);
			 var previews = grayTarget.window.previews;
			 var targetPreview = grayTarget.window.previews[grayTarget.window.previews.length-1];
			 
			 HT = new HistogramTransformation;
	         HT.H = [
				[0, 0.5, 1.0, 0.0, 1.0],
				[0, 0.5, 1.0, 0.0, 1.0],
				[0, 0.5, 1.0, 0.0, 1.0],
				[mask.image.median(), 0.5, 1.0, 0.0, 1.0],
			 ]
			
			for (let j = 0; j<i+2; j++) {
				if (j==0) {
					mmt(parameters.preservation/2 + i, targetPreview);
				} else mmt((j-1)+parameters.preservation, targetPreview);
				var name = getNewName(target.id+"_Layer"+j);
				let window = new ImageWindow(grayTarget.window.width, grayTarget.window.height, grayTarget.image.numberOfChannels, 
											 grayTarget.image.bitsPerSample, grayTarget.image.isReal, grayTarget.image.isColor, name);
				window.mainView.beginProcess();
				window.mainView.image.assign( targetPreview.image );
				window.mainView.endProcess();
				if (parameters.showTemp) window.show();
				parameters.layerNames[j] = name;		
				pixelMath(targetPreview, parameters.layerNames[0]);
			}
			pixelMath(mask, parameters.layerNames[0]);
			
			for (let j = 1; j<parameters.layerNames.length; j++) {
				pixelMath(mask, "M = ~((~"+parameters.layerNames[j]+")^"+(j+i)+"); ($T*(~M))+(("+parameters.layerNames[j]+")*M)");
			}
			HT.executeOn(mask, true);
			pixelMath(mask, "(~$T)^"+parameters.maskStrength);
			pixelMath(target, "(mtf(S, "+tempName+")*"+maskName+")+("+tempName+"*~"+maskName+")");
			
			for (let j = 0; j<parameters.layerNames.length; j++) {
				View.viewById(parameters.layerNames[j]).window.forceClose();
			}
			parameters.layerNames = [];
			grayTarget.window.forceClose();
			
		} else {
			mmt(layersToDisable, mask);
			HT.executeOn(mask, true);
			pixelMath(mask, "(~$T)^"+parameters.maskStrength);
			pixelMath(target, "(mtf(S, "+tempName+")*"+maskName+")+(temp*~"+maskName+")");
		}
		
		View.viewById(maskName).window.forceClose();
		View.viewById(tempName).window.forceClose();

		runs++;
	  }
	  pixelMath(parameters.targetView, "target", false, "", false);
	  View.viewById("target").window.forceClose();
	  var newMed = parameters.bgView.image.median();
	  var blackPoint = newMed-oldMed;
	  if (blackPoint > 0) {
		HT = new HistogramTransformation;
		HT.H = [
				[0, 0.5, 1.0, 0.0, 1.0],
				[0, 0.5, 1.0, 0.0, 1.0],
				[0, 0.5, 1.0, 0.0, 1.0],
				[parameters.bgView.image.median()/2, 0.5, 1.0, 0.0, 1.0],
			   ]
		HT.executeOn(parameters.targetView, true);
	  }
	  if (reps < parameters.repetitions) {
		console.noteln("Repeating: ", reps+1, "/", parameters.repetitions);
		reps++;
	    self.execute();
	  }
   };
}

var process = new processPrototype();

function colorspaceIsValid( image )
{
   // Grayscale is not a valid colorspace for this script
   return true;
}

function performChecksAndExecute()
{
   console.noteln( "Applying HDR: ", ImageWindow.activeWindow.currentView.id );

   if ( !parameters.targetView || !parameters.targetView.image )
   {
      ( new MessageBox(
         "<p>IHDR Error:<br><br>Undefined target view.</p>",
         TITLE,
         StdIcon_Warning,
         StdButton_Ok ) ).execute();
      return;
   }
   
   if (parameters.bgView == null) {
	   ( new MessageBox(
         "<p>IHDR Error:<br><br>Undefined background view.</p>",
         TITLE,
         StdIcon_Warning,
         StdButton_Ok ) ).execute();
      return;
   }
   
   if ((parameters.iterations*parameters.layersPer)+parameters.preservation > 16) {
	   ( new MessageBox(
         "<p>IHDR Error:<br><br>Too many layers!</p>"+
		 "<p>Reduce the number of iterations, the layers per iteration, or the layers preserved.</p>",
         TITLE,
         StdIcon_Warning,
         StdButton_Ok ) ).execute();
      return;
   }

   process.execute();
}

function executeInGlobalContext()
{
   ( new MessageBox(
      "<p>IHDR Error:<br><br>This script cannot be executed on global context.</p>",
      TITLE,
      StdIcon_Error,
      StdButton_Ok ) ).execute();

}

function executeOnTargetView( view )
{
   parameters.targetView = view;
   parameters.getParameters();
   performChecksAndExecute();
}

function main()
{
   console.hide();

   if ( Parameters.isGlobalTarget )
   {
      // Script has been launched in global context, execute and exit
      executeInGlobalContext();
      return;
   }
   if ( Parameters.isViewTarget )
   {
      // Script has been launched on a view target, execute and exit
      executeOnTargetView( Parameters.targetView );
      return;
   }


   parameters.targetView = ImageWindow.activeWindow.currentView;
   // Prepare the dialog
   let parametersDialog = new parametersDialogPrototype();

   // Runloop
   while ( true )
   {
      // Run the dalog
      if ( parametersDialog.execute() == 0 )
      {
         // Dialog closure forced
         return;
      }
	  
	  

      performChecksAndExecute();
   }
}

main();
